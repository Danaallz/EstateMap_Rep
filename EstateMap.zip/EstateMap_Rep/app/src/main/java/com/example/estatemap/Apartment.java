package com.example.estatemap;

public class Apartment {
    private Double price;
    private String imageURL;
    private String classification;  // "for sell" or "for rent"

    public Apartment(Double price, String imageURL, String classification) {
        this.price = price;
        this.imageURL = imageURL;
        this.classification = classification;
    }

    public Double getPrice() {
        return price;
    }

    public String getImageURL() {
        return imageURL;
    }

    public String getClassification() {
        return classification;
    }
}

